import {useState} from "react"
import NavBar from "./NavBar"
import ItemListContainer from "./ItemListContainer"
const App = () => {

    //let contador = 0 
    
    // const resultado = useState(0)
    // const estado = resultado[0]
    // const cambiarEstado = resultado [1]
    
    const [estado, setEstado] = useState(0)

    const setContador = () => {
        //contador = contador + 1 
        setEstado(estado + 1)
    }

    return (
        <>
         <NavBar/>
         <ItemListContainer nombre="Productos"/>
         <p>El contador va: {estado}</p>
         <button onClick={setContador}>Click</button>
        </>
    )
}
export default App
