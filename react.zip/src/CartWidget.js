const CartWidget = () =>{
    return(
        <a href="#" className="material-icons">shopping_cart</a>
    );
}
export default CartWidget;