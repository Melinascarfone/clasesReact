const ItemListContainer = ({nombre}) => {
    return(
        <nav>
            <h2>{nombre}</h2>
        </nav>
    )
}
export default ItemListContainer;
